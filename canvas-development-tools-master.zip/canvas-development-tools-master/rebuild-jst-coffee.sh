#!/bin/bash
bundle exec rake js:generate jst:compile
